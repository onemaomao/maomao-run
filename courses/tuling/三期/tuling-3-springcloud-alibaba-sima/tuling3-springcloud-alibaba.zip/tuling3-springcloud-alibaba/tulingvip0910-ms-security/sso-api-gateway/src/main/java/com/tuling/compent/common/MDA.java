package com.tuling.compent.common;

/**
 * 常量类
 * Created by smlz on 2019/12/26.
 */
public class MDA {

    public static final String clientId = "api-gateway";

    public static final String clientSecret = "smlz";

    public static final String checkTokenUrl = "http://auth-server/oauth/check_token";
}
