package com.tuling;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Tulingvip08MsCloudGatewaySentinelApplication {

	public static void main(String[] args) {
		SpringApplication.run(Tulingvip08MsCloudGatewaySentinelApplication.class, args);
	}

}
