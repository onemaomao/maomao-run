package com.tuling.entity;

import lombok.Data;

/**
 * Created by smlz on 2019/11/17.
 */
@Data
public class ProductInfo {

    private String productNo;

    private String productName;

    private String productStore;

    private double productPrice;
}
