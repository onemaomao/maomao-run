package com.tuling.vo;

import lombok.Data;

/**
 * Created by smlz on 2019/11/17.
 */
@Data
public class OrderVo {

    private String orderNo;

    private String userName;

    private String productName;

    private Integer productNum;
}
